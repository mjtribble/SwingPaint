/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swingpaint;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;
import java.awt.event.*;
import java.awt.image.BufferedImage;

/**
 *
 * @author melodytribble
 */
public class CanvasPanel extends JPanel implements MouseListener, MouseMotionListener{
  
    public static CanvasPanel inst;
    
   int startX, startY, widthX, heightY;
   Graphics2D gc;
   BufferedImage grid;
   int shape = 6;

    
    CanvasPanel(){
        setBackground(Color.WHITE);
        addMouseListener(this);
        addMouseMotionListener(this);
        startX = 0;
        startY = 0;
        widthX = 50;
        heightY = 50;
      
    }
    
    public static CanvasPanel getInstance(){
        if(inst == null)
            inst =  new CanvasPanel();
         return inst;
    }
    public void paintComponent(Graphics g)
    { 
         super.paintComponent(g);  
         Graphics2D g2 = (Graphics2D)g;//g2 paints on panel itself
         if(grid == null){
            int w = this.getWidth();//gets dimentions of Canvas panel
            int h = this.getHeight();
            grid = (BufferedImage)(this.createImage(w,h));//Creates a image of the same dimentions
            gc = grid.createGraphics();//gc is paintbrush for buffered image
           
         }
         g2.drawImage(grid, null, 0, 0);//starting in the top left corner. paints image onto panel
    }
    public void setShape(int x){
        shape = x;
    }
    public void draw(){
        gc.setColor(Color.black);
        if(shape ==1){//draws line
            gc.drawLine(startX, startY, widthX+startX, heightY+startY);
            repaint();
        }else if(shape == 2){//draws rectangle
            gc.fillRect(startX, startY, widthX, heightY);
            repaint();
        }else if(shape == 3){//draws oval
            gc.fillOval(startX, startY, widthX, heightY);
            repaint();
        }else if(shape == 4){//outline of rectangle
            gc.drawRect(startX, startY, widthX, heightY);
            repaint();    
        }else if(shape == 5){//outline of oval
            gc.drawOval(startX, startY, widthX, heightY);
            repaint();
        }else if(shape == 6){//clears drawing
            gc.clearRect(0, 0, this.getWidth(),this.getHeight());
            repaint();
        }else if(shape == 7){//draws line
            gc.drawLine(startX, startY, widthX+startX, heightY+startY);
            repaint();
        }
    }
    public void mousePressed(MouseEvent e){
        
        System.out.println("press");
        repaint();
        startX = e.getX();
        startY = e.getY();
    }  
    
    public void mouseReleased(MouseEvent e){
        
        if(startX>e.getX()){
            int endX = startX;
            startX = e.getX();
            widthX = endX - startX;
        }else{
            widthX = e.getX()-startX;
        }
        
        if(startY >e.getY()){
            int endY = startY;
            startY = e.getY();
            heightY = endY - startY;
        }else{
            heightY = e.getY() -startY; 
        }
        
        System.out.println("released");
        draw();
    }
    public void mouseDragged(MouseEvent e){
            System.out.println("Dragged called");
        if (shape ==7){
               widthX = e.getX()-startX;

               heightY = e.getY() -startY; 
            
            System.out.println("Dragged");
            draw();
            startX = e.getX();
            startY = e.getY();
        }
        
    }
    
    public void mouseExited(MouseEvent e){}
    
    public void mouseEntered(MouseEvent e){}
    
    public void mouseClicked(MouseEvent e){}

    public void mouseMoved(MouseEvent e) {
    }

   
}

//JColorChooser
//JFileChooser...saving
//JDialogOptions...popups
//Scroll Pane..scroll bar
//pull down menu
//
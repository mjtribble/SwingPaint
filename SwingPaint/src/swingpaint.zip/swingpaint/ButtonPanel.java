/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swingpaint;


import java.awt.Color;
import java.awt.Graphics;
import javax.swing.*;
import java.awt.event.*;
/**
 *
 * @author melodytribble
 */
public class ButtonPanel extends JPanel implements ActionListener{

    private static ButtonPanel inst;
    private JButton clearButton, fillRectButton, fillOvalButton, emptRectButton, emptOvalButton, lineButton, traceButton;
    String function = null;
    Graphics g;
    
    public static ButtonPanel getInstance(){
         
        if(inst == null)
           inst =  new ButtonPanel();
        return inst;
    }

    ButtonPanel(){
        setBackground(Color.DARK_GRAY);
        //setLayout(new FlowLayout());
        
        clearButton = new JButton("Clear");
        //clearButton.setIcon(new ImageIcon("clearIcon.png"));
        clearButton.addActionListener(this);
        add(clearButton);
        //validate();
        
        lineButton = new JButton("Line");
        lineButton.addActionListener(this);
        add(lineButton);
        
        traceButton = new JButton("Trace");
        traceButton.addActionListener(this);
        add(traceButton);
        
        fillRectButton = new JButton("Rectangle");
        fillRectButton.addActionListener(this);
        add(fillRectButton);
        
        fillOvalButton = new JButton("Oval");
        fillOvalButton.addActionListener(this);
        add(fillOvalButton);
        
        emptRectButton = new JButton("Rectangle Outline");
        emptRectButton.addActionListener(this);
        add(emptRectButton);
        
        emptOvalButton = new JButton("Oval Outline");
        emptOvalButton.addActionListener(this);
        add(emptOvalButton);
    }
    

     public void actionPerformed(ActionEvent ae){
         
         
        String command = ae.getActionCommand();
        
                if(command.equals("Clear")){
                    CanvasPanel.getInstance().setShape(6);
                    
                }else if(command.equals("Line")){
                    CanvasPanel.getInstance().setShape(1);
                    
                }else if(command.equals("Rectangle")){
                    CanvasPanel.getInstance().setShape(2);
                    
                }else if(command.equals("Oval")){
                    CanvasPanel.getInstance().setShape(3);
                    
                }else if(command.equals("Rectangle Outline")){
                    CanvasPanel.getInstance().setShape(4);                    
                    
                }else if(command.equals("Oval Outline")){
                    CanvasPanel.getInstance().setShape(5);  
                    
                }else if(command.equals("Trace")){
                    CanvasPanel.getInstance().setShape(7);
                }
        System.out.println(ae.getActionCommand());
     }
}   
    


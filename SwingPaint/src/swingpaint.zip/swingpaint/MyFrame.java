/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swingpaint;

import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JFrame;

/**
 *
 * @author melodytribble
 */
public class MyFrame extends JFrame {
    public static MyFrame inst;  
    
    public static MyFrame getInstance(){
        if(inst == null)
           inst = new MyFrame();
       
         return inst;
    }
    
    MyFrame(){
        
        super("Swing Paint");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//will stop program when X is hit
        Container c = getContentPane();
        c.add(ButtonPanel.getInstance(), BorderLayout.NORTH);
        getContentPane().add(CanvasPanel.getInstance(), BorderLayout.CENTER);
        setSize(1000, 1000);//sets open size
        setVisible(true);//make window visible
        
        
    }
}
